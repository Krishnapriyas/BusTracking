package com.bustrack.bustrack.model;

/**
 * Created by admininstrator on 10/11/17.
 */

public class SourceModel {
    private String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
