package com.bustrack.bustrack.model;

/**
 * Created by admininstrator on 12/11/17.
 */

public class LocationModel {
    private String lat;
    private String lng;

    public String getLat() {
        return lat;
    }

    public void setLat(String lat) {
        this.lat = lat;
    }

    public String getLng() {
        return lng;
    }

    public void setLng(String lng) {
        this.lng = lng;
    }
}
