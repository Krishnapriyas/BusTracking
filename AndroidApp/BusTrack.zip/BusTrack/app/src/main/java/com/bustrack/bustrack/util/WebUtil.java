package com.bustrack.bustrack.util;

/**
 * Created by admininstrator on 9/11/17.
 */

public class WebUtil {
    public static final String URL = "http://192.168.1.55:8080/BusTracking/";
}
