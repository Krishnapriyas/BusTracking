package com.bustrack.driver.util;

/**
 * Created by admininstrator on 11/11/17.
 */

public class WebUtil {
    public static final String URL = "http://192.168.1.55:8080/BusTracking/";
}
